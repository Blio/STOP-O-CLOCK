-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2014 at 04:53 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `twenzetu`
--
CREATE DATABASE IF NOT EXISTS `twenzetu` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `twenzetu`;

-- --------------------------------------------------------

--
-- Table structure for table `app_users`
--

CREATE TABLE IF NOT EXISTS `app_users` (
  `mem_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(8) NOT NULL,
  `password` varchar(8) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `emailaddress` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`mem_id`),
  KEY `mem_id` (`mem_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `app_users`
--

INSERT INTO `app_users` (`mem_id`, `username`, `password`, `fname`, `lname`, `emailaddress`, `gender`) VALUES
(8, 'Blio', '2612621', 'Bryan', 'Opiyo', 'bryan2opiyo@gmail.com', 'Male'),
(9, 'Mpesa', '7000', 'Bryan', 'Mbugua', 'ryan@gmail.com', ''),
(10, '', '', 'LO', '', '', ''),
(11, 'LIO', '123', 'LOICE', 'FELICE', 'loice@gmail.com', ''),
(12, 'Kimondio', '123', 'Blilali', 'Hamisi', 'bills@gmail.com', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
